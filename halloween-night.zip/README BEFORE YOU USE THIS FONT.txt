By installing or using this font, 
you are agreeing to the Product Usage Agreement:

- Here is the link to purchase a commercial license:
https://maknastudio.com/product/halloween-night/
- For Corporate use, you have to purchase a Corporate license
- Any donations are very appreciated. Paypal account for donation: 
https://paypal.me/maknastudio